<?php $__env->startSection('content'); ?>
<div class="row">
              <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                  <h4 class="card-title text-primary">Sales</h4><hr>
                  <form action="<?php echo e(route('sales')); ?>" method="GET">
          <div class="form-row">
            <div class="form-group col-md-3">
              
            <label for="from_date">From Date</label>
              <input type="date" class="form-control" id="from_date" name="from_date"
          value="<?php echo e(request('from_date')); ?>">
          
              <label for="to_date">To Date</label>
              <input type="date" class="form-control" id="to_date" name="to_date"
          value="<?php echo e(request('to_date')); ?>">
            </div>

            
            <div class="form-group col-md-3">
                            <label for="employee_id">Employee</label>
                            <select class="form-control" id="employee_id" name="employee_id">
                                <option value="">Select Employee</option>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($employee->id); ?>" <?php echo e(request('employee_id') == $employee->id ? 'selected' : ''); ?>>
                                    <?php echo e($employee->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

   


            <div class="form-group col-md-4">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary btn-block">Filter</button>
                        </div>
          </div>
        </form>
                    
                   
                    <!-- table goes here -->
                    

<table id="example" class="table table-striped" style="width:100%">
        <thead>
            <tr>
              <th>CUSTOMER NAME</th>
              <th>BUSINESS NAME</th>
              <th>KEYS</th>
              <th>AMOUNT</th>
              <th>TRANSACTION</th>
              <th>BALANCE</th>
              <th>STATE</th>
              <th>CITY</th>
              <th>EMPLOYEE ID</th>
              <th>ACTION</th>

            </tr>
        </thead> 
        <tbody>
        <?php $__currentLoopData = $Sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($sale->customer_name); ?></td>
            <td><?php echo e($sale->business_name); ?></td>
            <td><?php echo e($sale->keys); ?></td>
            <td><?php echo e($sale->amount); ?></td> 
            <td><?php echo e($sale->transaction); ?></td> 
            <td><?php echo e($sale->balance); ?></td> 
            <td><?php echo e($sale->state); ?></td>  
             <td><?php echo e($sale->city); ?></td> 
 
             
             <?php if(isset($sale->employee->name) && $sale->employee->name != null): ?>
             <td><?php echo e($sale->employee->name); ?></td> 
             <?php else: ?>
             <td></td> 
             <?php endif; ?>


             <td><a href="<?php echo e(route('sale_details', ['id' => $sale->id])); ?>" class="btn btn-info"><i class="fa fa-eye"></i></a></td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>     
                  </div>
                </div> 
              </div>
</div>
<?php $__env->stopSection(); ?>



<tbody>
                       
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP\htdocs\crm_admin\resources\views/showSales.blade.php ENDPATH**/ ?>