<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <!-- <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?> -->

        <!-- Bootstrap CSS -->
        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
        
        <!-- Vendor CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/feather/feather.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/mdi/css/materialdesignicons.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/ti-icons/css/themify-icons.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/font-awesome/css/font-awesome.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/typicons/typicons.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/simple-line-icons/css/simple-line-icons.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/css/vendor.bundle.base.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css')); ?>">
        
        <!-- Plugin CSS for this page -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/js/select.dataTables.min.css')); ?>">
        
        <!-- Your Custom CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
        
        <!-- Favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>" />
        <!-- DataTables CSS -->
        <link href="<?php echo e(asset('css/dataTables.bootstrap5.css')); ?>" rel="stylesheet">
        <!-- Include other CSS files if needed -->
    </head>
<body class="with-welcome-text">
    <div class="container-scroller">
<!-- here topbar -->
<?php if (isset($component)) { $__componentOriginal57b7ac81b71e7fe2d81fa75baf439455 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57b7ac81b71e7fe2d81fa75baf439455 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.topbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57b7ac81b71e7fe2d81fa75baf439455)): ?>
<?php $attributes = $__attributesOriginal57b7ac81b71e7fe2d81fa75baf439455; ?>
<?php unset($__attributesOriginal57b7ac81b71e7fe2d81fa75baf439455); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57b7ac81b71e7fe2d81fa75baf439455)): ?>
<?php $component = $__componentOriginal57b7ac81b71e7fe2d81fa75baf439455; ?>
<?php unset($__componentOriginal57b7ac81b71e7fe2d81fa75baf439455); ?>
<?php endif; ?>
    <div class="container-fluid page-body-wrapper">

<!-- here sidebar -->
<?php if (isset($component)) { $__componentOriginal2880b66d47486b4bfeaf519598a469d6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2880b66d47486b4bfeaf519598a469d6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2880b66d47486b4bfeaf519598a469d6)): ?>
<?php $attributes = $__attributesOriginal2880b66d47486b4bfeaf519598a469d6; ?>
<?php unset($__attributesOriginal2880b66d47486b4bfeaf519598a469d6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2880b66d47486b4bfeaf519598a469d6)): ?>
<?php $component = $__componentOriginal2880b66d47486b4bfeaf519598a469d6; ?>
<?php unset($__componentOriginal2880b66d47486b4bfeaf519598a469d6); ?>
<?php endif; ?>
    <div class="main-panel">
          <div class="content-wrapper">
    <header>
      
                </header>

    <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
            </main>

    </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block"> <a href="" target="_blank"></a>HBT CREATIONS PVT LTD</span>
              <span class="float-none float-sm-end d-block mt-1 mt-sm-0 text-center">Copyright © 2024. All rights reserved.</span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>

    <footer>
        <!-- Footer content goes here -->
    </footer>
    

    <!-- Bootstrap JS -->
    <script src="<?php echo e(asset('public/js/bootstrap.min.js')); ?>"></script>
    
    <!-- Vendor JS -->
    <script src="<?php echo e(asset('public/assets/vendors/js/vendor.bundle.base.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js')); ?>"></script>
    
    <!-- Plugin JS for this page -->
    <script src="<?php echo e(asset('public/assets/vendors/chart.js/chart.umd.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/vendors/progressbar.js/progressbar.min.js')); ?>"></script>
    
    <!-- Your custom JS -->
    <script src="<?php echo e(asset('public/assets/js/off-canvas.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/template.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/settings.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/hoverable-collapse.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/todolist.js')); ?>"></script>
    
    <!-- Custom JS for this page -->
    <script src="<?php echo e(asset('public/assets/js/jquery.cookie.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('public/assets/js/dashboard.js')); ?>"></script>

      <!-- DataTables JS -->
      <script src="<?php echo e(asset('public/js/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/dataTables.bootstrap5.min.js')); ?>"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/2.0.7/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/2.0.7/js/dataTables.bootstrap5.js"></script>

    <!-- for stATE CITY  -->
    <script src="<?php echo e(asset('public/assets/myjs/cities.js')); ?>"></script>
    <script language="javascript">print_state("sts");</script>
    <!-- <script src="assets/myjs/cities.js"></script>  -->

      <!-- Custom JS for DataTable initialization -->
      <script>
        $(document).ready(function() {
            new DataTable('#example');
        });
    </script>
    </body>
</html>
<?php /**PATH D:\PHP\htdocs\crm_admin\resources\views/layouts/app.blade.php ENDPATH**/ ?>