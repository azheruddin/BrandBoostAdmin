<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6 grid-margin stretch-card">
        <div class="card">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <div class="card-body">
                <h4 class="card-title text-primary">Assign Leads</h4>
                <hr>
                <form class="forms-sample" method="POST" action="assign_leads_employee"> 
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="state">State</label>
                        <select class="form-control" id="state" name="state_id" onchange="fetchCities(this.value)">
                            <option value="">Select State</option>
                            <?php $__currentLoopData = $States; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($state->state_id); ?>"><?php echo e($state->state_name); ?></option>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="city">City</label>
                        <select class="form-control" id="city" name="city_id">
                            <option value="">Select City</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="employee_id">Employee</label>
                        <select class="form-control" id="employee_id" name="employee_id">
                            <option value="">Select Employee</option>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                   
                    <button type="submit" class="btn btn-primary me-2">Assign</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function fetchCities(stateId) {
    if (stateId) {
        // alert(stateId);
        fetch(`/get-cities/${stateId}`)
            .then(response => response.json())
            .then(data => {
                const citySelect = document.getElementById('city');
                citySelect.innerHTML = '<option value="">Select City</option>';
                data.forEach(city => {
                    citySelect.innerHTML += `<option value="${city.city_id}">${city.city_name}</option>`;
                });
            })
            .catch(error => console.error('Error:', error));
    } else {
        document.getElementById('city').innerHTML = '<option value="">Select City</option>';
    }
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP\htdocs\crm_admin\resources\views/assignLeads.blade.php ENDPATH**/ ?>