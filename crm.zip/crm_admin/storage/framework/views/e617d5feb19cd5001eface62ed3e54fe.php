<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title text-primary">Today's Leads Feedback</h4>
                <hr>


                <form action="<?php echo e(route('filter_leads')); ?>" method="GET">
          <div class="form-row">
            <div class="form-group col-md-3">
              
             
            </div>

                           <div class="form-group col-md-3">
                            <label for="employee_id">Employee</label>
                            <select class="form-control" id="employee_id" name="employee_id">
                                <option value="">Select Employee</option>
                                
                                <?php if(isset($employees)): ?>

                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($employee->id); ?>" <?php echo e(request('employee_id') == $employee->id ? 'selected' : ''); ?>>
                                    <?php echo e($employee->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </select>
                        </div>

                        <div class="form-group col-md-3">
    <label for="lead_stage">Lead Stage</label>
    <select class="form-control" id="lead_stage" name="lead_stage">
        <option value="">Select Lead Stage</option>
        <option value="hot" <?php echo e(request('lead_stage') == 'hot' ? 'selected' : ''); ?>>Hot</option>
        <option value="interested" <?php echo e(request('lead_stage') == 'interested' ? 'selected' : ''); ?>>Interested</option>
        <option value="not_interested" <?php echo e(request('lead_stage') == 'not_interested' ? 'selected' : ''); ?>>Not Interested</option>
        <option value="no_answer" <?php echo e(request('lead_stage') == 'not_answer' ? 'selected' : ''); ?>>Not Answer</option>
        <option value="close" <?php echo e(request('lead_stage') == 'close' ? 'selected' : ''); ?>>Close</option>
    </select>
</div>

                       

            <div class="form-group col-md-4">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary btn-block">Filter</button>
                        </div>
          </div>
        </form>

                <!-- table goes here -->
                <table id="example" class="table table-striped" style="width:100%">
                    <thead>
                        <tr>
                            <th>SERIAL NO.</th>
                            <th>CUSTOMER NAME</th>
                            <th>EMAIL</th>
                            <th>PHONE</th>
                            <th>LEAD STAGE</th>
                            <th>LEAD DATE</th>
                            <th>NEXT FOLLOW UP</th>
                            <th>EMPLOYEE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $todayLeads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index +1); ?></td>
                            <td><?php echo e($lead->customer_name); ?></td>
                            <td><?php echo e($lead->customer_email); ?></td>
                            <td><?php echo e($lead->phone); ?></td>
                            <td><?php echo e($lead->lead_stage); ?></td>
                            <td><?php echo e($lead->created_at); ?></td>
                            <td><?php echo e($lead->next_follow_up); ?></td>
                            <td><?php echo e($lead->employee->name ?? ''); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>     
            </div>
        </div> 
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP\htdocs\crm_admin\resources\views/todayLeads.blade.php ENDPATH**/ ?>