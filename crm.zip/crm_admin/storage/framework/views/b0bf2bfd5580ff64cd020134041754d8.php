<?php echo e($slot); ?>

<?php /**PATH D:\PHP\htdocs\crm_admin\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>