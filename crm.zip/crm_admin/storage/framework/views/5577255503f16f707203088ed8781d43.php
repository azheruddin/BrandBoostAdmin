<?php $__env->startSection('content'); ?>




<div class="row">
  <div class="col-md-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
      <h4 class="card-title text-primary"> Today's Call History</h4><hr>


          <!-- Employee Filter Form -->
          <form action="<?php echo e(route('call_history_today')); ?>" method="GET">
            <div class="form-group col-md-3">
                <label for="">Employee</label> 
                <select class="form-control" id="employee_id" name="employee_id" onchange="this.form.submit()">
                    <option value="">Select Employee</option>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($employee->id); ?>" <?php echo e(request('employee_id') == $employee->id ? 'selected' : ''); ?>>
                        <?php echo e($employee->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <!-- <button type="submit" class="btn btn-primary btn-block">Search</button> -->
            </div>
        </form>
    

        <!-- table goes here -->


        <table id="example" class="table table-striped" style="width:100%">
          <thead>
            <tr>
              <th>Contact Name</th>
              <th>PHONE</th>
              <th>CALL TYPE</th>
              <th>DURATION</th>
               <th>DATE</th>
              <th>TIME</th>
              <th>EMPLOYEE</th>
              <th>ACTION</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $callHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $calls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
             <td><?php echo e($calls->contact_name); ?></td>
             <td><?php echo e($calls->phone); ?></td>
        <td><?php echo e($calls->type); ?></td>
        <?php
    $totalSeconds = $calls->call_duration;
    $minutes = floor($totalSeconds / 60);
    $seconds = $totalSeconds % 60;

    try {
        // Check if call_date is valid before parsing
        $callDate = \Carbon\Carbon::parse($calls->call_date);
        $formattedDate = $callDate->format('Y-m-d'); // Extract date part
        $formattedTime = $callDate->format('h:i:s A'); // Extract time part
    } catch (\Carbon\Exceptions\InvalidFormatException $e) {
        // Handle invalid date format by setting defaults or showing error
        $formattedDate = 'Invalid Date';
        $formattedTime = 'Invalid Time';
    }
?>

<td><?php echo e($minutes); ?> min <?php echo e($seconds); ?> sec</td>

         <td><?php echo e($formattedDate); ?></td>
        <td><?php echo e($formattedTime); ?></td>
        <?php if(isset($calls->employee->name) && $calls->employee->name != null): ?>
      <td><?php echo e($calls->employee->name); ?></td>
    <?php else: ?>
    <td></td>
  <?php endif; ?>

        <td><a href="<?php echo e(route('today_call_history_detail', ['call_id' => $calls->id])); ?>" class="btn btn-info"><i
            class="fa fa-eye"></i></a></a>

        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>



<tbody>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP\htdocs\crm_admin\resources\views/todayCalls.blade.php ENDPATH**/ ?>