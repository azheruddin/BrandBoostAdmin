<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title text-primary">Today Sales</h4><hr>
                <!-- table goes here -->
                <table id="example" class="table table-striped" style="width:100%">
                    <thead>
                        <tr>
                            <th>CUSTOMER NAME</th>
                            <th>BUSINESS NAME</th>
                            <th>KEYS</th> 
                            <th>AMOUNT</th>
                            <th>TRANSACTION</th>
                            <th>BALANCE</th>
                            <th>STATE</th>
                            <th>CITY</th>
                            <th>EMPLOYEE</th>
                            <th>ACTION</th>
                        </tr>
                    </thead> 
                    <tbody>
                        <?php $__currentLoopData = $Sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($sale->customer_name); ?></td>
                            <td><?php echo e($sale->business_name); ?></td>
                            <td><?php echo e($sale->keys); ?></td>
                            <td><?php echo e($sale->amount); ?></td> 
                            <td><?php echo e($sale->transaction); ?></td> 
                            <td><?php echo e($sale->balance); ?></td> 
                            <td>
                                <?php if($sale->state && $sale->state->state_name): ?>
                                    <?php echo e($sale->state->state_name); ?>

                                <?php else: ?>
                                    NA
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($sale->city && $sale->city->city_name): ?>
                                    <?php echo e($sale->city->city_name); ?>

                                <?php else: ?>
                                    NA
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($sale->employee && $sale->employee->name): ?>
                                    <?php echo e($sale->employee->name); ?>

                                <?php else: ?>
                                    NA
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('sale_details', ['id' => $sale->id])); ?>" class="btn btn-info">
                                    <i class="fa fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>     
            </div>
        </div> 
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP\htdocs\crm_admin\resources\views/todaySales.blade.php ENDPATH**/ ?>