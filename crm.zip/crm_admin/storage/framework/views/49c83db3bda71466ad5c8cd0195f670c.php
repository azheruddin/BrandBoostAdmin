<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title text-primary">Leads Summary by Employee</h4>
                <hr>

                <form action="<?php echo e(route('filter_leads')); ?>" method="GET">
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label for="employee_id">Employee</label>
                            <select class="form-control" id="employee_id" name="employee_id">
                                <option value="">Select Employee</option>
                                
                                <?php if(isset($employees)): ?>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($employee->id); ?>" <?php echo e(request('employee_id') == $employee->id ? 'selected' : ''); ?>>
                                            <?php echo e($employee->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>

                        <div class="form-group col-md-4">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary btn-block">Filter</button>
                        </div>
                    </div>
                </form>

                <!-- Leads table grouped by employee -->
                <table id="example" class="table table-striped" style="width:100%">
                    <thead>
                        <tr>
                            <th>SERIAL NO.</th>
                            <th>EMPLOYEE</th>
                            <th>ALL</th>
                            <th>TODAY UPLOAD</th>
                            <th>NEW</th>
                             <th>FOLLOW UP</th>
                            <th>HOT</th>
                            <th>INTERESTED</th>
                            <th>NOT ANSWERED</th>
                            <th>NOT INTERESTED</th>
                            <th>CLOSE</th>
                           
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($employee->name); ?></td>
                                <td><?php echo e($employee->all ?? 0); ?></td> <!-- Hot leads count -->
                                <td><?php echo e($employee->todayUploads ?? 0); ?></td> <!-- Hot leads count -->
                                <td><?php echo e($employee->newLeads ?? 0); ?></td> <!-- Hot leads count -->
                                <td><?php echo e($employee->followUpLeads ?? 0); ?></td> <!-- Hot leads count -->
                                <td><?php echo e($employee->hotLeads ?? 0); ?></td> <!-- Hot leads count -->
                                <td><?php echo e($employee->interestedLeads ?? 0); ?></td> <!-- Interested leads count -->
                                <td><?php echo e($employee->notAnsweredLeads ?? 0); ?></td> <!-- No Answer leads count -->
                                 <td><?php echo e($employee->notInterestedLeads ?? 0); ?></td> <!-- Not Interested leads count -->
                                <td><?php echo e($employee->closeLeads ?? 0); ?></td> <!-- No Answer leads count -->
                                <td><!-- Logic for the next follow-up can be added here --></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>     
            </div>
        </div> 
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP\htdocs\crm_admin\resources\views/countLeads.blade.php ENDPATH**/ ?>