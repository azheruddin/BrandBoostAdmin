<?php $__env->startSection('content'); ?>
<div class="row">
              <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                  <h4 class="card-title text-primary">Leads Feedback</h4><hr>
                  <form action="<?php echo e(route('leads_feedback')); ?>" method="GET">
          <div class="form-row">
            <div class="form-group col-md-3">
              
              <label for="from_date">From Date</label>
              <input type="date" class="form-control" id="from_date" name="from_date"
          value="<?php echo e(request('from_date')); ?>">
          
              <label for="to_date">To Date</label>
              <input type="date" class="form-control" id="to_date" name="to_date"
          value="<?php echo e(request('to_date')); ?>">
            </div>

            
            <div class="form-group col-md-3">
                            <label for="employee_id">Employee</label>
                            <select class="form-control" id="employee_id" name="employee_id">
                                <option value="">Select Employee</option>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($employee->id); ?>" <?php echo e(request('employee_id') == $employee->id ? 'selected' : ''); ?>>
                                    <?php echo e($employee->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

            <div class="form-group col-md-4">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary btn-block">Filter</button>
                        </div>
          </div>
        </form>
                    
                   
                    <!-- table goes here -->
                    

<table id="example" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th>CUSTOMER NAME</th>
                <th>EMAIL</th>
                <th>PHONE</th>
                 <th>LEAD STAGE</th>
               <th>LEAD DATE</th>
               <!-- <th>EXPECTED REVENUE</th> -->
               <th>NEXT FOLLOW UP</th>
               <!-- <th>NOTES</th> -->
               <th>EMPLOYEE</th>
               <th>ACTION</th>

            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $LeadsFeedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($leads->customer_name); ?></td>
            <td><?php echo e($leads->customer_email); ?></td>
            <td><?php echo e($leads->phone); ?></td>
            <td><?php echo e($leads->lead_stage); ?></td> 
             <td><?php echo e($leads->created_at); ?></td> 
             <!-- <td><?php echo e($leads->expected_revenue); ?></td>  -->
             <td><?php echo e($leads->next_follow_up); ?></td> 
             <!-- <td><?php echo e($leads->notes); ?></td>  -->
 
             
             <?php if(isset($leads->employee->name) && $leads->employee->name != null): ?>
             <td><?php echo e($leads->employee->name); ?></td> 
             <?php else: ?>
             <td></td> 
             <?php endif; ?>

              
            <td>
             <a href="<?php echo e(route('leadsfeedback_detail', ['id' => $leads->id])); ?>" class="btn btn-info">
    <i class="fa fa-eye"></i>
</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>     
                  </div>
                </div> 
              </div>
</div>
<?php $__env->stopSection(); ?>



<tbody>
                       
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP\htdocs\crm_admin\resources\views/LeadsFeedback.blade.php ENDPATH**/ ?>