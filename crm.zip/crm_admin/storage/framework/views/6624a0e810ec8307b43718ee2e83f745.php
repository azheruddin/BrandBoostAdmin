<?php $__env->startSection('content'); ?>

<div class="col-lg-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                  
                    <h4 class="card-title text-primary">Call History Details 
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">    
                    <a href="/call_history"button type="button" class="btn btn-primary justify-content-md-end" >Back</button></a>
                    </div>
                    <hr></h4>  
                    
                   
                    <!-- <p class="card-description"> Add class <code>.table-hover</code> -->
                    </p>
                    <div class="table-responsive">
                      <table class="table table-hover">
                       
                        <tbody>
                          <tr>
                            <td>Customer Name</td>
                            <td><?php echo e($calls->customer_name); ?></td>
                          </tr>
                          <tr>
                            <td>Customer Phone </td>
                            <td><?php echo e($calls->phone); ?></td>
                          </tr>
                          <tr>
                            <td>Call Type</td>
                            <td><?php echo e($calls->type); ?></td>
                          </tr>
                          <tr>
                            <td>Duration</td>
                            <td><?php echo e($calls->call_duration); ?></td>
                          </tr>
                          <tr>
                            <td>Call Date</td>
                            <td><?php echo e($calls->created_at); ?></td>
                          </tr>
                          <tr>
                            <td>Employee</td>
                            <td><?php echo e($calls->employee->name); ?></td>
                          </tr>
                          
                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>

















                       
                 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP\htdocs\crm_admin\resources\views/callHistoryDetails.blade.php ENDPATH**/ ?>