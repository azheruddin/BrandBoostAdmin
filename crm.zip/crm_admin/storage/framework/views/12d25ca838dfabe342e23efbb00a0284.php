<?php $__env->startSection('content'); ?>
<div class="row">
              <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
                  <div class="card-body"> 
                  <h4 class="card-title text-primary">Show Employees</h4><hr>
                   
                    <!-- table goes here -->
                     

<table id="example" class="table table-striped" style="width:100%">
  
        <thead>
            <tr>
                <th>Name</th>
                <!-- <th>Email</th> -->
                <th>Phone</th>
                <th>Employee Type</th>
                <th>Is Login</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($employee->name); ?></td> 
            <!-- <td><?php echo e($employee->email); ?></td> -->
            <td><?php echo e($employee->phone); ?></td>
            <td><?php echo e($employee->type); ?></td>
            <td>
            <a href="<?php echo e(route('employees.toggle_login', ['id' => $employee->id])); ?>" class="btn btn-<?php echo e($employee->is_login ? 'danger' : 'success'); ?>" onclick="return confirm('Are you sure you want to <?php echo e($employee->is_login ? 'logout' : 'login'); ?> this employee?');">
             <?php echo e($employee->is_login ? 'logout' : 'login'); ?>     
            </a>  
            </td>
            <td>
            <a href="<?php echo e(route('employees.toggle', ['id' => $employee->id])); ?>" class="btn btn-<?php echo e($employee->is_active ? 'danger' : 'success'); ?>" onclick="return confirm('Are you sure you want to <?php echo e($employee->is_active ? 'deactivate' : 'activate'); ?> this employee?');">
             <?php echo e($employee->is_active ? 'Deactivate' : 'Activate'); ?>     
            </a>
            </td>
            <td>              
          <a href="<?php echo e(route('employee_detail', ['employee_id' => $employee->id])); ?>" class="btn btn-info"><i class="fa fa-eye"></i></a>
          <a href="<?php echo e(route('employees.edit', ['id' => $employee->id])); ?>" class="btn btn-warning"><i class="fa fa-edit"></i></a>
          <form action="<?php echo e(route('employees.destroy', ['id' => $employee->id])); ?>" method="POST" style="display:inline;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this employee?');"><i class="fa fa-trash"></i></button>
          </form>

          <a href="<?php echo e(route('edit_password', ['id' => $employee->id])); ?>" class="btn btn-secondary"><i class="fa fa-key"></i></a> 

        </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
 </div>
</div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP\htdocs\crm_admin\resources\views/showEmployee.blade.php ENDPATH**/ ?>