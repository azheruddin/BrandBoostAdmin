<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title text-primary">Calls Status Today</h4>
                <hr>

                <!-- <form action="<?php echo e(route('call_duration')); ?>" method="GET"> -->
                <form action="<?php echo e(route('call_duration')); ?>" method="GET">
            <div class="form-group col-md-3">
                <label for="">Employee</label> 
                <select class="form-control" id="employee_id" name="employee_id" onchange="this.form.submit()">
                    <option value="">Select Employee</option>
                    <?php $__currentLoopData = $employeesSelect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($employee->id); ?>" <?php echo e(request('employee_id') == $employee->id ? 'selected' : ''); ?>>
                        <?php echo e($employee->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <!-- <button type="submit" class="btn btn-primary btn-block">Search</button> -->
            </div>
        </form>
                <!-- Calls and Leads table grouped by employee -->
                <table id="example" class="table table-striped" style="width:100%">
                    <thead>
                        <tr>
                            <th>SERIAL NO.</th>
                            <th>EMPLOYEE</th>
                            <th>TODAY CALLS</th> <!-- Today’s calls -->
                            <th>INCOMING CALLS</th> <!-- Incoming calls -->
                            <th>OUTGOING CALLS</th> <!-- Outgoing calls -->
                            <th>MISSED CALLS</th> <!-- Missed calls -->
                            <th>UNKNOWN CALLS</th> <!-- Unknown calls -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($employee->name); ?></td>
                                <td><?php echo e($employee->todayCalls ?? 0); ?></td> <!-- Today’s calls -->
                                <td><?php echo e($employee->incoming ?? 0); ?></td> <!-- Incoming calls -->
                                <td><?php echo e($employee->outgoing ?? 0); ?></td> <!-- Outgoing calls -->
                                <td><?php echo e($employee->missed ?? 0); ?></td> <!-- Missed calls -->
                                <td><?php echo e($employee->unknown ?? 0); ?></td> <!-- Unknown calls -->
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>     
            </div>
        </div> 
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PHP\htdocs\crm_admin\resources\views/callDurationSum.blade.php ENDPATH**/ ?>